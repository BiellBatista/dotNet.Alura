﻿namespace JornadaMilhas.API.DTO.Response;

public record RotaResponse(int Id, string origem, string destino);
