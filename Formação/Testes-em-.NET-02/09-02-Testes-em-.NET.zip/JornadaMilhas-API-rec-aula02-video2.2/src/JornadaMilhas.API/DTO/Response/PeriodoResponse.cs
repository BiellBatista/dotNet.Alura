﻿namespace JornadaMilhas.API.DTO.Response;

public record PeriodoResponse(DateTime dataInicio,DateTime dataFinal);

