﻿namespace JornadaMilhas.API.DTO.Auth
{
    public class UserDTO
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }
}
