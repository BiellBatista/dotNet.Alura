﻿namespace JornadaMilhas.API.DTO.Request;

public record PeriodoRequest(DateTime dataInicial, DateTime dataFinal);

