﻿namespace JornadaMilhas.API.DTO.Request;

public record RotaRequest(string origem, string destino);
