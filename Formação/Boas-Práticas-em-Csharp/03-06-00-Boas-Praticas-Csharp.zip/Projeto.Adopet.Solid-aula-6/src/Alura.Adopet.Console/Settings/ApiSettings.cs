﻿namespace Alura.Adopet.Console.Settings;
public class ApiSettings
{
    public const string Section = "AdopetApi";
    public string Uri { get; set; } = string.Empty;
}
