﻿namespace Alura.Adopet.API.Util
{
	internal enum TipoPet
	{
		Gato,
		Cachorro,
		Reptil,
		PorcoDaIndia
	}
}
