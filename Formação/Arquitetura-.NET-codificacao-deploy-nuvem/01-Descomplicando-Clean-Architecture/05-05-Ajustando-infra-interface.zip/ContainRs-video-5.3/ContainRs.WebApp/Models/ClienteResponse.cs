﻿namespace ContainRs.WebApp.Models;

public record ClienteResponse(string Id, string Nome, string Email);
