﻿namespace ScreenSound.API.Requests;

public record ArtistaRequest(string nome,string bio);

