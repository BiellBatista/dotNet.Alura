﻿namespace ScreenSound.Web.Requests;

public record GeneroRequest(string Nome, string Descricao);
