﻿namespace ScreenSound.Web.Response;

public class InfoPessoaResponse
{
    public string? Email { get; set; }
    public bool IsEmailConfirmed { get; set; }
}
