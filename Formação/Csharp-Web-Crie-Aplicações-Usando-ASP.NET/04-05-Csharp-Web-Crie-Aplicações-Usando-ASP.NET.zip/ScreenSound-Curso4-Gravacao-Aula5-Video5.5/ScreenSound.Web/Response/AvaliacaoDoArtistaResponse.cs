﻿namespace ScreenSound.Web.Response;

public record AvaliacaoDoArtistaResponse(int ArtistaId, double Nota);
