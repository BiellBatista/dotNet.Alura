﻿namespace ScreenSound.API.Requests;

public record AvaliacaoArtistaRequest(int ArtistaId, int Nota);
