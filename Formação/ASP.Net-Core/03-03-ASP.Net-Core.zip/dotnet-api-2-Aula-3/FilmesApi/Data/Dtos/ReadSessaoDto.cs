﻿namespace FilmesApi.Data.Dtos
{
    public class ReadSessaoDto
    {
        public int Id { get; set; }
    }
}
