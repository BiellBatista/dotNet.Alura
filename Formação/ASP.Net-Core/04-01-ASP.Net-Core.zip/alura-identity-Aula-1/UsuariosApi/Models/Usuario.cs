﻿using Microsoft.AspNetCore.Identity;

namespace UsuariosApi.Models
{
    public class Usuario
    {
    }
}
