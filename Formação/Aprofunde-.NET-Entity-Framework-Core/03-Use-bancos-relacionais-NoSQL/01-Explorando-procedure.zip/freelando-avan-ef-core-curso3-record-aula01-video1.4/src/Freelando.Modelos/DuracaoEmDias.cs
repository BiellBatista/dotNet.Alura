﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Freelando.Modelo;
public enum DuracaoEmDias
{
    MenosDeUm,
    DeUmASete,
    DeSeteAQuinze,
    DeQuinzeATrinta,
    MaisDeTrinta
}
