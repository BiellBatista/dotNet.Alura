﻿namespace Freelando.Modelo;

public enum StatusCandidatura
{
    Aprovada,
    Recusada,
    Pendente
}