﻿using Freelando.Dados.Repository.Base;
using Freelando.Modelo;

namespace Freelando.Dados.Repository;
public interface IContratoRepository : IRepository<Contrato>
{
}

