﻿namespace Freelando.Modelo;
public enum StatusServico
{
    Disponivel,
    Pausado,
    Concluido,
    Cancelado,
    EmAndamento

}
