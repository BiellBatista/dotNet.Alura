﻿namespace Freelando.Api.Responses;

public record EspecialidadeResponse(Guid Id, string? Descricao);

