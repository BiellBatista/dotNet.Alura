﻿namespace Freelando.Modelo;
public enum StatusProjeto
{
    Disponivel,
    Pausado,
    Concluido,
    Cancelado

}
