﻿namespace Freelando.Modelo;

public enum StatusCandidatura
{
    Aprovada,
    Pendente,
    Recusada
}