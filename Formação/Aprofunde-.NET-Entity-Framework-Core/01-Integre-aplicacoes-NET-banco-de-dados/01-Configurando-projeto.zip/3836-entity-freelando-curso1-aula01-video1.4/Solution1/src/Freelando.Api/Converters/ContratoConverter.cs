﻿namespace Freelando.Api.Converters;

public class ContratoConverter
{
}
