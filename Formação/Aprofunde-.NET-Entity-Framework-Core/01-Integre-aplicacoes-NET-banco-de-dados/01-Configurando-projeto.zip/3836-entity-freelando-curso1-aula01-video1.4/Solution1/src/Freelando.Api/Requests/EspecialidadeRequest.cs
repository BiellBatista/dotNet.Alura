﻿namespace Freelando.Api.Requests;

public record EspecialidadeRequest(Guid Id, string? Descricao);
