﻿namespace Freelando.Api.Converters;

public class EspecialidadeConverter
{
}
