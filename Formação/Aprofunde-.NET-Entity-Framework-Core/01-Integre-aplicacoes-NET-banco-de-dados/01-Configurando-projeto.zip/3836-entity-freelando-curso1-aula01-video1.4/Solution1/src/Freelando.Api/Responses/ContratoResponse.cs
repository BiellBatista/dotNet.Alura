﻿using Freelando.Modelo;

namespace Freelando.Api.Responses;

public record ContratoResponse(Guid Id, double? Valor);
