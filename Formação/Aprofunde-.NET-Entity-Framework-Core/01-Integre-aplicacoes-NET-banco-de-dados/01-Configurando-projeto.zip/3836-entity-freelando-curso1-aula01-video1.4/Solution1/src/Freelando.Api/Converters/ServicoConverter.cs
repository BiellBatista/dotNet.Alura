﻿namespace Freelando.Api.Converters;

public class ServicoConverter
{
}
