﻿namespace Adopet.Models.Enums;

public enum TipoPet
{
    Gato,
    Cachorro
}
