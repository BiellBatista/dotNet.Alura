﻿namespace Adopet.Models.Enums;

public enum StatusAdocao
{
    AGUARDANDO_AVALIACAO,
    APROVADO,
    REPROVADO
}