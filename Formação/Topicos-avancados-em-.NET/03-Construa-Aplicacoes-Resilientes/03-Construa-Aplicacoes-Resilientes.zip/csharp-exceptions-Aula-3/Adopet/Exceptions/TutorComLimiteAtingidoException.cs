﻿namespace Adopet.Exceptions;

public class TutorComLimiteAtingidoException : Exception
{
    public TutorComLimiteAtingidoException(string? mensagem) :
        base(mensagem)
    { }
}