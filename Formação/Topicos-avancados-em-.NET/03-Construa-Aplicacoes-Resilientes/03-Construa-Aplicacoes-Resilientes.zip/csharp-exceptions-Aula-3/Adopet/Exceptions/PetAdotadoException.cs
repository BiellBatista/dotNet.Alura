﻿namespace Adopet.Exceptions;

public class PetAdotadoException : Exception
{
    public PetAdotadoException(string? mensagem) : base(mensagem) { }   
}
