﻿namespace Adopet.Exceptions;

public class PetEmProcessoDeAdocaoException : Exception
{
    public PetEmProcessoDeAdocaoException(string? mensagem) : base(mensagem) { }   
}
