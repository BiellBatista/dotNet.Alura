﻿namespace SerenattoPreGravacao.Dados;
public class DadosPedidos
{
    public static List<List<int>> QuantidadeItensPedidosPorDia = new List<List<int>>
    {
        new List<int> {1, 2, 5, 7},
        new List<int> {10, 6 },
        new List<int> {5, 20, 3, 6, 1, 1},
        new List<int> {1, 1, 3, 15},
        new List<int> {2, 1, 5, 12, 6},
        new List<int> {9, 1, 3, 16},
        new List<int> {1, 3, 1, 2, 2, 4, 7}
    };
}
