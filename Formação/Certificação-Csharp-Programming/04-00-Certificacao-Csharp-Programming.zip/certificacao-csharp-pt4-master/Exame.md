# Exame 70-483
## Programação em CSHARP

![](img1.png)
![](img2.png)
![](img3.png)
![](img4.png)