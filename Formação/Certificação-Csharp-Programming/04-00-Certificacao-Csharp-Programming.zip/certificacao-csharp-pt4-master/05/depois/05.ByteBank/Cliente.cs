﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.ByteBank
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string CPF { get; set; }
        public string Profissao { get; set; }
    }
}
