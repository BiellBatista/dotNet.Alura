﻿namespace Alura.Adopet.Console.Settings;

public class AdopetApiSettings
{
    public const string Section = "AdopetApi";
    public string Uri { get; set; } = string.Empty;
}
