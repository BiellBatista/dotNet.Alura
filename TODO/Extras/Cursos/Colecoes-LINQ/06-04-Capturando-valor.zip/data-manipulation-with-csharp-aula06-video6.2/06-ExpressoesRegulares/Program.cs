﻿using System.Reflection.PortableExecutable;
using System.Text.RegularExpressions;

using var arquivo = new FileStream("musicas.csv", FileMode.Open, FileAccess.Read);
using var stream = new StreamReader(arquivo);


var musicas = ObterMusicas(stream)
    .Take(20);

ExibirMusicasEmTabela(musicas);

void TestandoRegex()
{
    var linha = "The Broken Road;Rolling Stones;16:39;Rock, Blues Rock;13/09/1974";
    var match = Regex.Match(linha, @"(\d{1,2}):(\d\d)"); // ?: opcional; *: 0..N; +: 1..N  {} 1..2

    Console.WriteLine($"Padrão encontrado? {match.Success}");
    if (match.Success)
    {
        foreach (var group in match.Groups)
        {
            Console.WriteLine(group);
        }

        string padraoCompleto = match.Groups[0].Value;
        string minutos = match.Groups[1].Value;
        string segundos = match.Groups[2].Value;

        Console.WriteLine($"Minutos encontrados: {minutos}");
        Console.WriteLine($"Segundos encontrados: {segundos}");

    }

}

void ExibirMusicas(IEnumerable<Musica> musicas)
{
    var titulo = "\nMúsicas do arquivo:"; // string literal
                                          //var titulo = new string("\nMúsicas do arquivo:");

    Console.WriteLine(titulo);
    foreach (var musica in musicas)
    {
        var linha = $"\t- {musica.Titulo} ({musica.Artista}) - {musica.Duracao}s [{musica.Lancamento}]";
        Console.WriteLine(linha);
    }
}

void ExibirMusicasEmTabela(IEnumerable<Musica> musicas)
{
    var titulo = "\nMúsicas do arquivo:"; // string literal
    Console.WriteLine(titulo);

    var colunaTitulo = "Título".PadRight(40);
    var colunaArtista = "Artista".PadRight(30);
    var colunaDuracao = "Duração".PadRight(10);
    var colunaLancamento = "Lançada Em".PadRight(15);
    Console.WriteLine($"{colunaTitulo}{colunaArtista}{colunaDuracao}{colunaLancamento}");
    var borda = "".PadRight(100, '=');
    Console.WriteLine(borda);

    foreach (var musica in musicas)
    {
        var duracao = string.Format("{0,-10:F3}", musica.Duracao / 60.0);
        var linha = $"{musica.Titulo,-40}{musica.Artista,-30}{duracao}{musica.Lancamento,-15:dd/MM/yyyy}";
        Console.WriteLine(linha);
    }
}

IEnumerable<Musica> ObterMusicas(StreamReader stream)
{
    var linha = stream.ReadLine();
    while (linha is not null)
    {
        var partes = linha.Split(';');
        if (partes.Length == 5)
        {
            //var partesDuracao = partes[2].Split(':'); // 00:00
            //int minutos = int.TryParse(partesDuracao[0], out int min) ? min : 3;
            //int segundos = int.TryParse(partesDuracao[1], out int seg) ? seg : 25;

            var match = Regex.Match(linha, @"(\d{1,2}):(\d\d)");
            int duracao = 180;
            if (match.Success)
            {
                string minutos = match.Groups[1].Value;
                string segundos = match.Groups[2].Value;
                duracao = Convert.ToInt32(minutos) * 60 + Convert.ToInt32(segundos);
            }

            var musica = new Musica
            {
                Titulo = string.IsNullOrWhiteSpace(partes[0]) ? "Título não encontrado" : partes[0],
                Artista = string.IsNullOrWhiteSpace(partes[1]) ? "Artista não encontrado" : partes[1],
                Duracao = duracao,
                Generos = partes[3].Split(',', StringSplitOptions.TrimEntries),
                Lancamento = DateTime.TryParse(partes[4], out var data) ? data : DateTime.Today
            };
            yield return musica;
        }
        linha = stream.ReadLine();
    }
}

class Musica
{
    public string Titulo { get; set; }
    public string Artista { get; set; }
    public int Duracao { get; set; }
    public IEnumerable<string> Generos { get; set; }
    public DateTime Lancamento { get; set; }

    public override string ToString()
    {
        return $"{Titulo} ({Artista}) - {Duracao}s [{Lancamento}]";
    }
}