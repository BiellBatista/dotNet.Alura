﻿using System.ComponentModel.DataAnnotations;

using var arquivo = new FileStream("musicas.csv", FileMode.Open, FileAccess.Read);
using var stream = new StreamReader(arquivo);


// alterar o nome de uma música

var musicaMaisLonga = ObterMusicas(stream)
    .MaxBy(m => m.Duracao);

if (musicaMaisLonga is not null)
{
    Console.WriteLine($"Música mais longa é {musicaMaisLonga.Titulo} do {musicaMaisLonga.Artista} com {musicaMaisLonga.Duracao / 60} minutos.");

    // The Eletric Dream => Detalhes
    musicaMaisLonga.Titulo = musicaMaisLonga.Titulo.Replace("e", "3");
    musicaMaisLonga.Artista = musicaMaisLonga.Artista.ToUpper();

    Console.WriteLine($"Música mais longa é {musicaMaisLonga.Titulo} do {musicaMaisLonga.Artista} com {musicaMaisLonga.Duracao / 60} minutos.");
}
else Console.WriteLine("Não havia uma música nessa condição");


void StringComoArrayDeChar()
{
    char[] caracteres; // equivalente a uma string

    var musicasComT = ObterMusicas(stream)
        .Where(m => m.Titulo.StartsWith('T'))
        //.Where(m => m.Titulo[0] == 'T')
        .OrderBy(m => m.Lancamento)
        .Take(50);

    ExibirMusicas(musicasComT);
}

void ValidandoSenhaForte()
{
    var senha = "Daniel@7";
    /* 
        Senha será forte se:
        0. possui pelo menos 8 caracteres
        1. possui alguma letra maiúscula
        2. possui alguma letra minúscula
        3. possui algum número
        4. possui algum símbolo
     */
    var totalCaracteres = senha.Count();
    var totalMaiusculas = senha.Count(c => char.IsLetter(c) && char.IsUpper(c));
    var totalMinusculas = senha.Count(c => char.IsLetter(c) && char.IsLower(c));
    var totalNumeros = senha.Count(c => char.IsDigit(c));
    var totalSimbolos = senha.Count(c => !char.IsLetterOrDigit(c));
    if (totalCaracteres < 8 || totalMaiusculas == 0 || totalMinusculas == 0 || totalNumeros == 0 || totalSimbolos == 0)
    {
        Console.WriteLine("Senha digitada é fraca!");
    }
    else
    {
        Console.WriteLine("Senha digitada é forte!");
    }

}


void ExibirMusicas(IEnumerable<Musica> musicas)
{
    var titulo = "\nMúsicas do arquivo:"; // string literal
    //var titulo = new string("Músicas do arquivo:"); // alocação tradicional
    Console.WriteLine(titulo);
    foreach (var musica in musicas)
    {
        var linha = $"\t- {musica.Titulo} ({musica.Artista}) - {musica.Duracao}s [{musica.Lancamento}]";
        //var linha2 = "\t- " + musica.Titulo + " (" + musica.Artista + ") " + musica.Duracao + "s [" + musica.Lancamento + "]";
        Console.WriteLine(linha);
    }
}

IEnumerable<Musica> ObterMusicas(StreamReader stream)
{
    var linha = stream.ReadLine();
    while (linha is not null)
    {
        var partes = linha.Split(';');
        var musica = new Musica
        {
            Titulo = partes[0],
            Artista = partes[1],
            Duracao = Convert.ToInt32(partes[2]),
            Generos = partes[3].Split(',', StringSplitOptions.TrimEntries),
            Lancamento = Convert.ToDateTime(partes[4])
        };
        yield return musica;
        linha = stream.ReadLine();
    }
}

class Musica
{
    public string Titulo { get; set; }
    public string Artista { get; set; }
    public int Duracao { get; set; }
    public IEnumerable<string> Generos { get; set; }
    public DateTime Lancamento { get; set; }
}