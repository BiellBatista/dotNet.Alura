﻿/*
    Seja um arquivo com músicas em formato CSV (Comma Separated Values). 

    Implemente as funções abaixo:
    //     [ ] Leia-o como uma coleção de músicas
    //     [ ] Filtre a coleção por artista (por ex. Coldplay, Metallica, AC/DC)
    //     [ ] Filtre a coleção por duração (por ex. maiores que 5 minutos)
    //     [ ] Ordene a coleção por artista
    //     [ ] Ordene a coleção por artista e em seguida por músicas com duração crescente
    //     [ ] Recupere as 10 músicas mais longas
    //     [ ] Crie uma coleção de artistas
    //     [ ] Crie uma coleção de gêneros
    //     [ ] Crie uma coleção de artistas e suas músicas
    //     [ ] Informe a duração média das músicas da coleção
    //     [ ] Informe a duração total das músicas da coleção
    //     [ ] Informe qual artista tem mais músicas na coleção
    //     [ ] Filtre a coleção por gênero (por ex. rock)
 
*/

using var arquivo = new FileStream("musicas.csv", FileMode.Open, FileAccess.Read);
using var stream = new StreamReader(arquivo);

// arquivo CSV >> 1. coleção de músicas >> 2. filtro por artistas que começam com a letra C >> 3. descarte as 5 primeiras músicas
var musicasDoMetallica = ObterMusicas(stream) //obtenção dos dados: arquivos
    .Where(m => m.Artista.StartsWith("M"))
    .Skip(5)
    .Take(10)
    .OrderBy(m => m.Artista)
    //.OrderByDescending(m => m.Artista) // modo decrescente
    //.ThenBy(m => m.Titulo)
    .ThenByDescending(m => m.Duracao); // Em seguida ordene por...

ExibirMusicas(musicasDoMetallica);

void ExibirMusicas(IEnumerable<Musica> musicas)
{
    Console.WriteLine("\n10 Primeiras músicas do arquivo:");
    foreach (var musica in musicas)
    {
        Console.WriteLine($"\t- {musica.Titulo} ({musica.Artista}) - {musica.Duracao} segundos");
    }
}

IEnumerable<Musica> ObterMusicas(StreamReader stream)
{
    var linha = stream.ReadLine();
    while (linha is not null)
    {
        Console.WriteLine("Processando linha...");
        var partes = linha.Split(';');
        var musica = new Musica
        {
            Titulo = partes[0],
            Artista = partes[1],
            Duracao = Convert.ToInt32(partes[2]),
            Generos = []
        };
        yield return musica;
        linha = stream.ReadLine();
    }
}

class Musica
{
    public string Titulo { get; set; }
    public string Artista { get; set; }
    public int Duracao { get; set; }
    public string[] Generos { get; set; }
}