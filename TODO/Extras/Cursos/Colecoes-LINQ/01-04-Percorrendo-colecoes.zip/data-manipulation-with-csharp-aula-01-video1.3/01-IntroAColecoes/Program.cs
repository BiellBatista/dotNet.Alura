﻿using System.Collections.Generic;

var diasDaSemana = new string[] { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado" };

var carrinho = new List<Produto>()
{
    new Produto { Id = 1, Nome = "Leite", Preco = 6.89 }
};

carrinho.Add(new Produto { Id = 2, Nome = "Biscoito", Preco = 3.99 });

//PercorrendoColecaoComFor();
//PercorrendoColecaoComWhile();
PercorrendoColecaoComForEach();

void PercorrendoColecaoComForEach()
{
    foreach (var produto in carrinho)
    {
        Console.WriteLine($"Produto {produto.Nome} - {produto.Preco:F2}");
    }
    foreach(var dia in diasDaSemana)
    {
        Console.WriteLine(dia);
    }
}

void PercorrendoColecaoComWhile()
{
    int i = 0;
    while (i < diasDaSemana.Length)
    {
        var dia = diasDaSemana[i];
        Console.WriteLine($"Dia {dia}");
        i++;
    }
    
}

void PercorrendoColecaoComFor()
{
    for (int i = 0; i < carrinho.Count; i++)
    {
        var produto = carrinho[i];
        Console.WriteLine($"Produto {produto.Nome} - {produto.Preco:F2}");
    }
}

class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public double Preco { get; set; }
}