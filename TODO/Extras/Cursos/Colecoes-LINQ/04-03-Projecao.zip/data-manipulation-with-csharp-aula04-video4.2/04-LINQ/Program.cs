﻿/*
    Seja um arquivo com músicas em formato CSV (Comma Separated Values). 

    Implemente as funções abaixo:
    //     [x] Leia-o como uma coleção de músicas
    //     [x] Filtre a coleção por artista (por ex. Coldplay, Metallica, AC/DC)
    //     [x] Filtre a coleção por duração (por ex. maiores que 5 minutos)
    //     [x] Ordene a coleção por artista
    //     [x] Ordene a coleção por artista e em seguida por músicas com duração crescente
    //     [x] Recupere as 10 músicas mais longas
    //     [x] Crie uma coleção de artistas
    //     [x] Crie uma coleção de gêneros
    //     [ ] Crie uma coleção de artistas e suas músicas
    //     [ ] Informe a duração média das músicas da coleção
    //     [ ] Informe a duração total das músicas da coleção
    //     [ ] Informe qual artista tem mais músicas na coleção
    //     [ ] Filtre a coleção por gênero (por ex. rock)
 
*/

using var arquivo = new FileStream("musicas.csv", FileMode.Open, FileAccess.Read);
using var stream = new StreamReader(arquivo);

ProjetandoGeneros(stream);


void ProjetandoGeneros(StreamReader stream)
{
    var generos = ObterMusicas(stream)
        //.Select(m => m.Generos); // IEnumerable<Musica> -> IEnumerable<string[]> !
        .SelectMany(m => m.Generos) // IEnumerable<Musica> -> IEnumerable<string> (achata)
        .Distinct()
        .OrderBy(g => g);

    Console.WriteLine($"\nListando Gêneros:");
    foreach(var genero in generos)
    {
        Console.WriteLine($"\t - {genero}");
    }
}

void ProjetandoArtistas(StreamReader stream)
{
    //var artistas = ObterMusicas(stream)
    //    .DistinctBy(m => m.Artista) // filtro baseado na igualdade do argumento do método
    //    .Select(m => m.Artista)
    //    .OrderBy(a => a);

    var artistas = ObterMusicas(stream)
        .Select(m => m.Artista) // transformação/projeção/mapeamento entre tipos (T -> Z)
        .Distinct() // filtro baseado na igualdade dos elementos de entrada
        .OrderBy(a => a);

    Console.WriteLine($"\nArtistas no arquivo:");
    foreach (var artista in artistas)
    {
        Console.WriteLine($"\t - {artista}");
    }
}

void OperacoesDeFiltroEOrdenacao(StreamReader stream)
{
    var musicasDoMetallica = ObterMusicas(stream) //obtenção dos dados: arquivos
        .Where(m => m.Artista.StartsWith("M"))
        .Skip(5)
        .Take(10)
        .OrderBy(m => m.Artista)
        //.OrderByDescending(m => m.Artista) // modo decrescente
        //.ThenBy(m => m.Titulo)
        .ThenByDescending(m => m.Duracao); // Em seguida ordene por...

    ExibirMusicas(musicasDoMetallica);
}

void ExibirMusicas(IEnumerable<Musica> musicas)
{
    Console.WriteLine("\n10 Primeiras músicas do arquivo:");
    foreach (var musica in musicas)
    {
        Console.WriteLine($"\t- {musica.Titulo} ({musica.Artista}) - {musica.Duracao} segundos");
    }
}

IEnumerable<Musica> ObterMusicas(StreamReader stream)
{
    var linha = stream.ReadLine();
    while (linha is not null)
    {
        //Console.WriteLine("Processando linha...");
        var partes = linha.Split(';');
        var musica = new Musica
        {
            Titulo = partes[0],
            Artista = partes[1],
            Duracao = Convert.ToInt32(partes[2]),
            Generos = partes[3].Split(',').Select(g => g.Trim())
        };
        yield return musica;
        linha = stream.ReadLine();
    }
}

class Musica
{
    public string Titulo { get; set; }
    public string Artista { get; set; }
    public int Duracao { get; set; }
    public IEnumerable<string> Generos { get; set; }
}