﻿using System.Collections.Generic;

var diasDaSemana = new string[] { "Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado" };

var carrinho = new List<Produto>()
{
    new Produto { Id = 1, Nome = "Leite", Preco = 6.89 }
};

carrinho.Add(new Produto { Id = 2, Nome = "Biscoito", Preco = 3.99 });

class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public double Preco { get; set; }
}