using System;
using System.Collections.Generic;
using CursoMongoDB.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using Newtonsoft.Json;
using CursoMongoDB.Contexts;
using CursoMongoDB.Services;

namespace CursoMongoDB.Programs
{
    public static class Program_10_4
    {
        public static async Task ExecutarAsync()
        {

            var connectionString = "mongodb+srv://root:root@cluster0.dxav3bh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
            var contexto = new MongoContext(connectionString, "NoticiasDB");
            var NoticiaService = new NoticiaService(contexto);

            Console.WriteLine("--- Testando a função de Explain para uma consulta com índice ---");

            // Vamos criar um filtro que sabemos que deve usar nosso índice de DataPublicacao
            var filtro = Builders<BsonDocument>.Filter.Gte("DataPublicacao", new DateTime(2025, 1, 1));

            // Chamando nossa nova função de diagnóstico
            await NoticiaService.ExibirPlanoExecucaoAsync(filtro);
        }

        private static void ImprimirResultados(string titulo, List<BsonDocument> documentos, string campoOrdenado)
        {
            Console.WriteLine($"--- {titulo} ---");
            if (documentos == null || documentos.Count == 0)
            {
                Console.WriteLine("Nenhum documento encontrado.");
                Console.WriteLine("\n-------------------------------------------------------\n");
                return;
            }

            foreach (var doc in documentos)
            {
                var valorOrdenado = "N/A";
                try
                {
                    // Lógica para extrair o valor do campo ordenado, mesmo que seja aninhado ou não exista
                    if (doc.Contains(campoOrdenado) && !doc[campoOrdenado].IsBsonNull)
                    {
                        valorOrdenado = doc[campoOrdenado].ToString();
                    }
                    else if (campoOrdenado.Contains(".")) // Para campos aninhados como "Anexos.Cliques"
                    {
                        var partes = campoOrdenado.Split('.');
                        if (doc.Contains(partes[0]) && doc[partes[0]].IsBsonArray)
                        {
                            // Pega o valor do primeiro anexo que corresponda (simplificação para exibição)
                            valorOrdenado = doc[partes[0]].AsBsonArray.FirstOrDefault()?[partes[1]].ToString() ?? "N/A";
                        }
                    }
                }
                catch { /* Ignora erros se o campo não existir no documento específico */ }

                Console.WriteLine($"  - Título: {doc["Titulo"]}, ({campoOrdenado}: {valorOrdenado})");
            }
            Console.WriteLine($"Total de resultados: {documentos.Count}");
            Console.WriteLine("\n-------------------------------------------------------\n");
        }
    }
}