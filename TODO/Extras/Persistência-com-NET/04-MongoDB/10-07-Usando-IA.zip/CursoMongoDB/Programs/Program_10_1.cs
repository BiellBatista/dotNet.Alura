using System;
using System.Collections.Generic;
using CursoMongoDB.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using Newtonsoft.Json;
using CursoMongoDB.Contexts;
using CursoMongoDB.Services;

namespace CursoMongoDB.Programs
{
    public static class Program_10_1
    {
        public static async Task ExecutarAsync()
        {

            var connectionString = "mongodb+srv://root:root@cluster0.dxav3bh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
            var contexto = new MongoContext(connectionString, "NoticiasDB");
            var NoticiaService = new NoticiaService(contexto);

            try
            {
                await NoticiaService.CriarIndiceDataPublicacaoAsync();
                Console.WriteLine("--- Operação de criação de índice finalizada ---");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro ao criao o indice: {ex.Message}");
            }


        }

        private static void ImprimirResultadosFacet(string titulo, BsonArray resultados)
        {
            Console.WriteLine($"\n{titulo}");
            if (!resultados.Any()) { /* ... */ } // Código de impressão já definido

            foreach (var item in resultados.Select(r => r.AsBsonDocument))
            {
                Console.Write($"Tag: {item["Tag"],-20}");
                foreach (var elemento in item.Elements)
                {
                    if (elemento.Name != "Tag")
                    {
                        string valorFormatado = elemento.Value.IsDouble ? $"{elemento.Value.AsDouble:F2}" : elemento.Value.ToString();
                        Console.Write($" | {elemento.Name}: {valorFormatado}");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}