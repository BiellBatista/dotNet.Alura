using System;
using System.Collections.Generic;
using CursoMongoDB.Models;
using MongoDB.Driver;

namespace CursoMongoDB.Programs
{
    public static class Program_3_1a
    {
        public static void Executar()
        {
            var connectionString = "mongodb+srv://root:root@cluster0.dxav3bh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
            var client = new MongoClient(connectionString);
            var database = client.GetDatabase("NoticiasDB");
            var collection = database.GetCollection<dynamic>("noticias");
            database.CreateCollection("noticias");
            Console.WriteLine("Banco de dados 'NoticasDB' e coleção 'noticias' criados com sucesso!");

        }
    }
}