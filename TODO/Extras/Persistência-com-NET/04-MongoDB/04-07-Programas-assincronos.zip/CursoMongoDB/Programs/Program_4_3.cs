using System;
using System.Collections.Generic;
using CursoMongoDB.Models;
using MongoDB.Driver;
using MongoDB.Bson;
using Newtonsoft.Json;

namespace CursoMongoDB.Programs
{
    public static class Program_4_3
    {
        public static void Executar()
        {

            var connectionString = "mongodb+srv://root:root@cluster0.dxav3bh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
            var client = new MongoClient(connectionString);
            var database = client.GetDatabase("NoticiasDB");
            var collection = database.GetCollection<BsonDocument>("noticias");

            string caminhoArquivo = "C:\\temp\\CursoMongoDB\\4905 - Vídeo 4.3 - Lista.js";
            if (!File.Exists(caminhoArquivo))
            {
                Console.WriteLine("Arquivo noticias.json não encontrado!");
                return;
            }

            string conteudoJson = File.ReadAllText(caminhoArquivo);
            var listaNoticias = JsonConvert.DeserializeObject<List<NoticiaClass>>(conteudoJson);

            var listaBson = new List<BsonDocument>();
            foreach (var Noticia in listaNoticias)
            {
                listaBson.Add(Noticia.ToBson());
            }

            try
            {
                collection.InsertMany(listaBson);
                Console.WriteLine("Notícias incluídas com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ocorreu um erro ao tentar inserir a lista de notícias:");
                Console.WriteLine(ex.Message);
            }
        }
    }
}