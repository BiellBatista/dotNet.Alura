﻿using CursoMongoDB.Programs;

class Program
{
    static void Main(string[] args)
    {
        // Chame apenas o programa do vídeo desejado
        Program_2_4.Executar();

    }
}
