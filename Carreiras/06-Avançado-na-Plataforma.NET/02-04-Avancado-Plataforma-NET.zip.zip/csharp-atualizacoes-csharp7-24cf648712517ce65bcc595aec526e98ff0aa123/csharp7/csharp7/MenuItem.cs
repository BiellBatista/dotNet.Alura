﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace csharp7
{
    public abstract class MenuItem
    {
        public abstract void Main();
    }
}
