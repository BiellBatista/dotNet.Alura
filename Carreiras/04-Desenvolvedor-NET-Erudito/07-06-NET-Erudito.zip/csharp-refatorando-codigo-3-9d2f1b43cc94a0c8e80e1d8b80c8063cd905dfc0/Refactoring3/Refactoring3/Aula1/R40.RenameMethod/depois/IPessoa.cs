﻿namespace refatoracao.R40.RenameMethod.depois
{
    interface IPessoa
    {
        decimal GetCreditoDisponivel();
        string GetNome();
    }
}