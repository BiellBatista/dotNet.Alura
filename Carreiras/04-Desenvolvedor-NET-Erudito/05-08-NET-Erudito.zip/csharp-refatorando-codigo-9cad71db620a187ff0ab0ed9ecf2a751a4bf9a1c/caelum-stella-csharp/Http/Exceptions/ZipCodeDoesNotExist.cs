﻿using System;

namespace Caelum.Stella.CSharp.Http.Exceptions
{
    public class ZipCodeDoesNotExist : Exception
    {
    }
}
