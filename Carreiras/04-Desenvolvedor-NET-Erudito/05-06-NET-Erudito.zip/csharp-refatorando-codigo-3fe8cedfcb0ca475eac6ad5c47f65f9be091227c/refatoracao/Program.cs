﻿using System;

namespace refatoracao
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
