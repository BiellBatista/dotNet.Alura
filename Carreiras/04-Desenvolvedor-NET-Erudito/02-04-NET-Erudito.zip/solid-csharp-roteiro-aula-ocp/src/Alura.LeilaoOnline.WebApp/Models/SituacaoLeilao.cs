﻿namespace Alura.LeilaoOnline.WebApp.Models
{
    public enum SituacaoLeilao
    {
        Rascunho,
        Pregao,
        Finalizado,
        Arquivado
    }
}
