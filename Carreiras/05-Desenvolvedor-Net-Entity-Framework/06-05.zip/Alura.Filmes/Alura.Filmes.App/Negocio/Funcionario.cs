﻿namespace Alura.Filmes.App.Negocio
{
    public class Funcionario : Pessoa
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}
