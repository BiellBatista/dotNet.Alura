﻿namespace Alura.Filmes.App.Negocio
{
    public class Cliente : Pessoa
    {
        
    }
}
