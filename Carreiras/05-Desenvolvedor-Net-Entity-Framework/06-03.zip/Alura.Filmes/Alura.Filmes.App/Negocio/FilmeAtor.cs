﻿namespace Alura.Filmes.App.Negocio
{
    public class FilmeAtor
    {
        public Filme Filme { get; set; }
        public Ator Ator { get; set; }
    }
}
