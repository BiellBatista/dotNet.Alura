﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Apis.Bigquery.v2;
using Google.Apis.Bigquery.v2.Data;
using Google.Cloud.BigQuery.V2;

namespace CursoBQCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            CursoBQCSharp001();
        }

        // Acesso ao projeto do BigQuery

        static void CursoBQCSharp001()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");
            Console.ReadLine();
        }
    }
}
