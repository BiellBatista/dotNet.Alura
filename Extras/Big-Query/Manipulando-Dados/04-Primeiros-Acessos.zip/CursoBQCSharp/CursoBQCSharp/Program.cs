﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Apis.Bigquery.v2;
using Google.Apis.Bigquery.v2.Data;
using Google.Cloud.BigQuery.V2;

namespace CursoBQCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // CursoBQCSharp001();
            // CursoBQCSharp002();
            CursoBQCSharp003();
        }

        // Acesso ao projeto do BigQuery

        static void CursoBQCSharp001()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");
            Console.ReadLine();
        }

        // Consultando dados de uma tabela

        static void CursoBQCSharp002()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "SELECT * FROM `curso-big-query-09652.Suco_de_Frutas.FABRICA`;";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Consula efetuada com sucesso.");

            Console.ReadLine();
        }

        static void CursoBQCSharp003()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "INSERT INTO `curso-big-query-09652.Suco_de_Frutas.FABRICA` VALUES (5, '005', 'Fábrica de Rio Grande do Sul');";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Comando efetuado com sucesso.");

            Console.ReadLine();
        }

    }
}
