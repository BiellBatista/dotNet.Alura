﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Apis.Bigquery.v2;
using Google.Apis.Bigquery.v2.Data;
using Google.Cloud.BigQuery.V2;

namespace CursoBQCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // CursoBQCSharp001();
            // CursoBQCSharp002();
            // CursoBQCSharp003();
            // CursoBQCSharp004A();
            CursoBQCSharp004B();
        }

        // Acesso ao projeto do BigQuery

        static void CursoBQCSharp001()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");
            Console.ReadLine();
        }

        // Consultando dados de uma tabela

        static void CursoBQCSharp002()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "SELECT * FROM `curso-big-query-09652.Suco_de_Frutas.FABRICA`;";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Consula efetuada com sucesso.");

            Console.ReadLine();
        }

        // Exemplo de inclusão de dados na tabela

        static void CursoBQCSharp003()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "INSERT INTO `curso-big-query-09652.Suco_de_Frutas.FABRICA` VALUES (5, '005', 'Fábrica de Rio Grande do Sul');";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Comando efetuado com sucesso.");

            Console.ReadLine();
        }

        // Exemplo de alteração de dados da tabela

        static void CursoBQCSharp004A()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "UPDATE `curso-big-query-09652.Suco_de_Frutas.FABRICA` SET DESC_FABRICA = 'Fábrica de Brasília' WHERE ID_FABRICA = 6;";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Comando efetuado com sucesso.");

            Console.ReadLine();
        }

        // Exemplo de exslução de dados da tabela

        static void CursoBQCSharp004B()
        {
            string projetoID = "curso-big-query-09652";
            var cliente = BigQueryClient.Create(projetoID);
            Console.WriteLine("Conexão ao projeto " + projetoID + " realizado com sucesso.");

            string consultaSQL = "DELETE FROM  `curso-big-query-09652.Suco_de_Frutas.FABRICA` WHERE ID_FABRICA = 6;";
            var resultadoSQL = cliente.ExecuteQuery(consultaSQL, null);
            Console.WriteLine("Comando efetuado com sucesso.");

            Console.ReadLine();
        }

    }
}
