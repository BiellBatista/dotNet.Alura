# aspnet-identity-parte-2
Curso dedicado ao curso da Alura de AspNet Identity Parte 2, lecionado pelo instrutor Guilherme Matheus Costa.
