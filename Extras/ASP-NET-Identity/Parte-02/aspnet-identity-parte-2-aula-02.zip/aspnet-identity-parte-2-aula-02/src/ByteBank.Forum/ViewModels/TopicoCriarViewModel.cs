﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ByteBank.Forum.ViewModels
{
    public class TopicoCriarViewModel
    {
        public string Titulo { get; set; }
        public string Conteudo { get; set; }
    }
}