﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ByteBank.Forum.ViewModels
{
    public class UsuarioFuncaoViewModel
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public bool Selecionado { get; set; }
    }
}