﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projetoBlog.Models
{
    public class Usuario
    {
        // XXX TRABALHE AQUI
        // Crie aqui a clase de usuários.
    }
}