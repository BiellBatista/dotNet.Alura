﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projetoBlog.Models
{
    public class Comentario
    {
        // XXX TRABALHE AQUI
        // Crie aqui a clase de comentários
    }
}