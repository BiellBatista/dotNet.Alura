﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projetoBlog.Models
{
    public class Publicacao
    {
        // XXX TRABALHE AQUI
        // Crie aqui a clase da publicação
    }
}