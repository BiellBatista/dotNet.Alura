﻿using LojaWeb.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LojaWeb.DAO
{
    public class VendasDAO
    {
        public void Adiciona(Venda venda)
        {

        }

        public IList<Venda> Lista()
        {
            return new List<Venda>();
        }
    }
}