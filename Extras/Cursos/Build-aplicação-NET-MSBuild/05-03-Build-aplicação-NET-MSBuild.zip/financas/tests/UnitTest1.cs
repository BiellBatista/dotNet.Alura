using System;
using Xunit;

namespace FinancasTest
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
