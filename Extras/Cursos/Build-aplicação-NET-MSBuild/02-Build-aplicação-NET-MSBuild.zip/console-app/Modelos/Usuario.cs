namespace Alura.MsBuild.Modelos
{
	public class Usuario
	{
	
	}
}