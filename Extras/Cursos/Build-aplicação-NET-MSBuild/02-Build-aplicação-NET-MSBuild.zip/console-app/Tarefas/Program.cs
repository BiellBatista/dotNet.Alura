using System;

namespace Alura.MsBuild.ConsoleApp
{
	public class Program 
	{
		static void Main()
		{
			Console.WriteLine("Alô, mundo do MsBuild!");
		}
	}
}