namespace Alura.Financas.Modelos
{
	public class Cliente
	{
		public string Nome { get; }
		
		public Cliente(string nome)
		{
			Nome = nome;
		}
	}
}