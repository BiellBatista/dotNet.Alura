# Alura-Paralelismo-com-CSharp-e-.NET
Progresso de nosso desenvolvimento no curso de Paralelismo com C# e .NET
