﻿namespace Alura.Adopet.API.Dominio
{
    public enum TipoPet
    {
        Gato,
        Cachorro,
        Reptil,
        PorcoDaIndia
    }
}
