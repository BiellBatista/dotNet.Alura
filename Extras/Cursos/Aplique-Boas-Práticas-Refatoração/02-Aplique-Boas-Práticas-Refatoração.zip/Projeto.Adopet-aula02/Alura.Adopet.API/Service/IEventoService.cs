﻿namespace Alura.Adopet.API.Service
{
    public interface IEventoService
    {
        void GenerateFakeDate();
    }
}
