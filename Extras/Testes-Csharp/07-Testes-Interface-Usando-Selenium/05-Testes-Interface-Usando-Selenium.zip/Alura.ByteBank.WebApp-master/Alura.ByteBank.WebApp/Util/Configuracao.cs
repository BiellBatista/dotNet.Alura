﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alura.ByteBank.WebApp.Util
{
    public static class Configuracao
    {
      public static string Secret = "$6$rounds=5000$_ usesomesillystringforsaltAlura$";
    }
}
