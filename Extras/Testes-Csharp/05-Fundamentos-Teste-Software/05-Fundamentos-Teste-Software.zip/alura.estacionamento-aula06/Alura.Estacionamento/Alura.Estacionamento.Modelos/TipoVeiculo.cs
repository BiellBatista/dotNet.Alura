﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alura.Estacionamento.Alura.Estacionamento.Modelos
{
    //Enumeração para classificar os veículos em carros ou motos.
   public enum TipoVeiculo
    {
        Automovel=0,
        Motocicleta=1
    }
}
