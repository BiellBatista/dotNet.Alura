﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Alura.LeilaoOnline.WebApp.Models
{
    public class FavoritoViewModel
    {
        public int IdLeilao { get; set; }
        public int IdInteressada { get; set; }
    }
}
