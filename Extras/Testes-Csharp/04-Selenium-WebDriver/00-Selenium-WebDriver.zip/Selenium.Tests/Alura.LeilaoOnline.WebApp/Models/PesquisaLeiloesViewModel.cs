﻿namespace Alura.LeilaoOnline.WebApp.Models
{
    public class PesquisaLeiloesViewModel
    {
        public string Termo { get; set; }
        public string[] Categorias { get; set; }
        public string Andamento { get; set; }
    }
}
